pos=Player:getWorldPos()
pos.y=pos.y+1.5
x=pos.x
y=pos.y
z=pos.z
tpos=pos:getHeadForwardPosBlocked(15.0)
tx=tpos.x
ty=tpos.y
tz=tpos.z
Server:DrawParticle("SNOWBALL",200,tpos,0.0,15,0.0)
Server:Wait(1000)
for i=-9,9 do
   for j=-9,9 do
      ax=i*0.25
      ay=j*0.25
      if (ax*ax+ay*ay<=2*2)
      then
         Player:Command("summon minecraft:arrow "..(tx+ax).." "..(ty+10).." "..(tz+ay).." {Motion:[0.0,-2.0,0.0],direction:[0.0,0.0,0.0]}")
      end
   end
end
Server:Wait(2000)
Player:Command("kill @e[distance=..50,type=minecraft:arrow]")